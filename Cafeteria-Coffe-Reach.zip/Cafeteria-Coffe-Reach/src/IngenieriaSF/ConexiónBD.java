package IngenieriaSF;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class ConexiónBD { //Clase para hacer la conexión a la base de datos, y las operaciones en ella. 

    Connection c;
    String url = "jdbc:mariadb://localhost:3306/coffee_reach";
    String user = "root";
    String pwd = "root";
    Statement stat = null;
    ResultSet rel = null;
    

    public boolean conectar() { //Metodo que hace la conexión a la base de datos
        try {
            c = DriverManager.getConnection(url, user, pwd);
            stat = c.createStatement();       
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean insertarDatos(String tabla, String datos) { //Metodo que realiza la insercción de datos en una tabla, de la base de datos.
        String sql = "INSERT INTO " + tabla + " () values (" + datos + ");";
        try {
            stat.executeUpdate(sql);
            return true;
        } catch (SQLException ex) {
            return false;
        }
    }
     

    public int conteoCarrito(String tabla, String dato) { //Metodo que elimina la fila de una tabla
        String sql = String.format("SELECT COUNT(*) AS total FROM %s WHERE clienteID = '82cedc8f-1ba9-11ef-bc9e-d4939021fdda';", tabla);
         rel = null;
         int conteo = 0;
        try {
            rel = stat.executeQuery(sql);
            if (rel.next()) {
                conteo = rel.getInt("total");
                
            }
        } catch (SQLException ex) {
              
        }
        return conteo;
    }


    public void eliminar(String tabla, String idconsultar, String dato) { //Metodo que elimina la fila de una tabla
        String sql = String.format("DELETE FROM %s WHERE %s = %s", tabla, idconsultar, dato);
        try {
            stat.executeQuery(sql);
            JOptionPane.showMessageDialog(null, "Se elimino el dato seleccionado");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar el dato");
        }
    }
    
     public boolean consultaWhere(String tabla, String valor, String dato) { //Metodo que realiza la consulta por medio del id, que se ingrese.
        String sql = String.format("SELECT * FROM %s WHERE ", tabla);
        boolean resultadoConsulta = false;
        sql+= String.format("%s = '%s';", valor, dato);      
        rel = null;
        try {
            rel = stat.executeQuery(sql);
            if (rel.next()) {
                 resultadoConsulta = true; 
            }else{

            }
        } catch (SQLException ex) {
              resultadoConsulta = false;    
        }
        return resultadoConsulta;
    }

    public boolean consulta(String tabla, String valores[], String datos[]) { //Metodo que realiza la consulta por medio del id, que se ingrese.
        String sql = String.format("SELECT * FROM %s WHERE ", tabla);
        boolean resultadoConsulta = false;
        for (int i = 0; i < datos.length; i++) {
            if (i < valores.length - 1) {
                sql+= String.format("%s = '%s' AND ", valores[i], datos[i]);
            }
            else{
                sql+=String.format("%s = '%s';", valores[i], datos[i]); 
              }
        }
        rel = null;
        try {
            rel = stat.executeQuery(sql);
            if (rel.next()) {
                 resultadoConsulta = true; 
            }else{
                 JOptionPane.showMessageDialog(null, "El usuario o contraseña son incorrectos");
            }
        } catch (SQLException ex) {
              resultadoConsulta = false;    
        }
        return resultadoConsulta;
    }
    
     public boolean consultaDato(String tabla, String valores[], String datos[], String columnaConsulta) { //Metodo que realiza la consulta por medio del id, que se ingrese.
        String sql = String.format("SELECT %s FROM %s WHERE ", columnaConsulta, tabla );
        boolean resultadoConsulta = false;
        for (int i = 0; i < datos.length; i++) {
            if (i < valores.length - 1) {
                sql+= String.format("%s = '%s' AND ", valores[i], datos[i]);
            }
            else{
                sql+=String.format("%s = '%s';", valores[i], datos[i]); 
              }
        }
        rel = null;
        try {
            rel = stat.executeQuery(sql);
            if (rel.next()) {
                 resultadoConsulta = true; 
            }else{
              
            }
        } catch (SQLException ex) {
              resultadoConsulta = false;    
        }
        return resultadoConsulta;
    }

    public ResultSet consultaTablaCompleta(String tabla, String dato) {//Metodo que realiza la consulta de todos los datos de una tabla
        String sql = String.format("SELECT * FROM %s WHERE %s", tabla, dato);
        rel = null;
        try {
            rel = stat.executeQuery(sql);
        } catch (SQLException ex) {
        }
        return rel;
    }
    
     public boolean actulizar(String tabla, String id_tabla, String id, String valores[], String datos[]){//Metodo que realiza el actualizado de datos
          String sql = String.format("UPDATE %s SET ", tabla);
          for (int i = 0; i < valores.length; i++) {           
              if (i < valores.length-1) { 
                  sql+=String.format("%s = %s, ", valores[i], datos[i]);       
              }else{
                  sql+=String.format("%s = %s", valores[i], datos[i]); 
              }
         }
          sql += String.format(" WHERE %s = %s;", id_tabla, id);
        try {
             stat.executeUpdate(sql);        
             JOptionPane.showMessageDialog(null, "Se actualizaron los datos correctamente");
               return true;
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Error al actualizar los dattos " + ex.getMessage());
             return false;
        }   
     }

    public void crearTablas(String tabla, String datos) { //Metodo para crear tablas en la base de datos
        String sql = "CREATE TABLE " + tabla + " (" + datos + ");";
        try {
            stat.execute(sql);
            JOptionPane.showMessageDialog(null, "Se creo la tabla");
        } catch (SQLException ex) {
        }
    }
    
    public void desconectar() { //Metodo que desconecta la base de datos
        try {
            if (c != null) {
                c.close();
                stat.close();               
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

}
