
package IngenieriaSF;

import java.awt.Color;
import java.awt.Desktop;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;


/**
 *
 * @author Jael Pineda Quiroz
 */
public class AcercaPagina extends javax.swing.JPanel {
 JPanel JPPrincipal;
    /**
     * Creates new form AcercaPagina
     */
    public AcercaPagina(JPanel panelPrincipal) {
        initComponents();
         this.JPPrincipal = panelPrincipal;
         JPPrincipal.add(this);
         carritoIndex();
    }
    
    
     public void carritoIndex(){
            ConexiónBD conexion = new ConexiónBD();
            conexion.conectar();
             int carrito = conexion.conteoCarrito("orden", "82cedc8f-1ba9-11ef-bc9e-d4939021fdda"); 
             JLNotificación.setText(String.format("%d", carrito));  
             JPCabezera.revalidate();
             JPCabezera.repaint();
             this.repaint();
             this.revalidate();
             conexion.desconectar();
      }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        JPPrincipalSC = new javax.swing.JPanel();
        JPCabezera = new javax.swing.JPanel();
        JBInicio = new javax.swing.JButton();
        JBAcerca = new javax.swing.JButton();
        JBMenu = new javax.swing.JButton();
        JBTitulo = new javax.swing.JButton();
        JBCarrito = new javax.swing.JButton();
        JBUsuario = new javax.swing.JButton();
        JLNotificación = new javax.swing.JLabel();
        JPCuerpo = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        JBLeerVision = new javax.swing.JButton();
        JBLeerMHistory = new javax.swing.JButton();
        JPPiePagina = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        JBTwitter = new javax.swing.JButton();
        JBFacebook = new javax.swing.JButton();
        JBInstagram = new javax.swing.JButton();
        JBYoutube = new javax.swing.JButton();

        setMinimumSize(new java.awt.Dimension(1280, 700));
        setPreferredSize(new java.awt.Dimension(1280, 700));

        jScrollPane1.setBorder(null);
        jScrollPane1.setAutoscrolls(true);
        jScrollPane1.setDoubleBuffered(true);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(1280, 700));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(1280, 700));

        JPPrincipalSC.setBackground(new java.awt.Color(255, 255, 255));
        JPPrincipalSC.setForeground(new java.awt.Color(255, 255, 255));
        JPPrincipalSC.setAutoscrolls(true);
        JPPrincipalSC.setMinimumSize(new java.awt.Dimension(1260, 960));
        JPPrincipalSC.setPreferredSize(new java.awt.Dimension(1260, 960));

        JPCabezera.setBackground(new java.awt.Color(255, 255, 255));
        JPCabezera.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        JPCabezera.setMinimumSize(new java.awt.Dimension(1261, 65));
        JPCabezera.setPreferredSize(new java.awt.Dimension(1270, 65));

        JBInicio.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBInicio.setText("Inicio");
        JBInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JBInicio.setBorderPainted(false);
        JBInicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBInicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBInicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBInicioMouseExited(evt);
            }
        });
        JBInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBInicioActionPerformed(evt);
            }
        });

        JBAcerca.setBackground(new java.awt.Color(51, 153, 255));
        JBAcerca.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBAcerca.setText("Acerca");
        JBAcerca.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JBAcerca.setBorderPainted(false);
        JBAcerca.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBAcerca.setDoubleBuffered(true);
        JBAcerca.setSelected(true);

        JBMenu.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBMenu.setText("Menú");
        JBMenu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JBMenu.setBorderPainted(false);
        JBMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBMenu.setDoubleBuffered(true);
        JBMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                JBMenuMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBMenuMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBMenuMouseExited(evt);
            }
        });
        JBMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBMenuActionPerformed(evt);
            }
        });

        JBTitulo.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        JBTitulo.setText("RITZKEY'S");
        JBTitulo.setBorder(null);
        JBTitulo.setBorderPainted(false);
        JBTitulo.setContentAreaFilled(false);
        JBTitulo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBTitulo.setDefaultCapable(false);
        JBTitulo.setFocusable(false);
        JBTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTituloActionPerformed(evt);
            }
        });

        JBCarrito.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesPgInicio/carroCompraIcon.png"))); // NOI18N
        JBCarrito.setBorder(null);
        JBCarrito.setContentAreaFilled(false);
        JBCarrito.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBCarrito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBCarritoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBCarritoMouseExited(evt);
            }
        });
        JBCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBCarritoActionPerformed(evt);
            }
        });

        JBUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesPgInicio/usuarioIcon.png"))); // NOI18N
        JBUsuario.setBorder(null);
        JBUsuario.setContentAreaFilled(false);
        JBUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBUsuarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBUsuarioMouseExited(evt);
            }
        });
        JBUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBUsuarioActionPerformed(evt);
            }
        });

        JLNotificación.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JLNotificación.setForeground(new java.awt.Color(255, 255, 255));
        JLNotificación.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLNotificación.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/circuloIcon.png"))); // NOI18N
        JLNotificación.setText("0");
        JLNotificación.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout JPCabezeraLayout = new javax.swing.GroupLayout(JPCabezera);
        JPCabezera.setLayout(JPCabezeraLayout);
        JPCabezeraLayout.setHorizontalGroup(
            JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JBTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(347, 347, 347)
                .addComponent(JBInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(JBAcerca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(JBMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(350, 350, 350)
                .addComponent(JBUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(JBCarrito)
                .addGap(0, 0, 0)
                .addComponent(JLNotificación)
                .addGap(20, 20, 20))
        );
        JPCabezeraLayout.setVerticalGroup(
            JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addComponent(JBTitulo)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JLNotificación)
                    .addComponent(JBUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBAcerca, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        JPCuerpo.setBackground(new java.awt.Color(255, 255, 255));
        JPCuerpo.setMinimumSize(new java.awt.Dimension(1260, 1008));
        JPCuerpo.setPreferredSize(new java.awt.Dimension(1260, 658));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel25.setText("Visión");

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Conocénos");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("<html>Nuestra visión como cafetería es<br>" +
            "ser reconocidos como la mejor<br>" +
            "cafetería de la ciudad, ofreciendo<br>" +
            "productos de alta calidad y un<br>" +
            "servicio excepcional para satisfacer<br>" +
            "los gustos y necesidades de...<br>");
        jLabel1.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/CafeImg.png"))); // NOI18N

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel27.setText("Historia");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText(("<html>La cafetería comenzó como un<br>" +
            "sueño y un objetivo el cual lograr.<br>" +
            "En el 2015 abrimos nuestro primer<br>" +
            "negocio que siendo pequeño aun<br>" +
            "mostraba un gran potencial por<br>" +
            "delante...</html>"));
    jLabel3.setVerticalAlignment(javax.swing.SwingConstants.TOP);

    JBLeerVision.setBackground(new java.awt.Color(146, 154, 222));
    JBLeerVision.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
    JBLeerVision.setForeground(new java.awt.Color(255, 255, 255));
    JBLeerVision.setText("Leer más");
    JBLeerVision.setBorder(null);
    JBLeerVision.setBorderPainted(false);
    JBLeerVision.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            JBLeerVisionMouseEntered(evt);
        }
        public void mouseExited(java.awt.event.MouseEvent evt) {
            JBLeerVisionMouseExited(evt);
        }
    });
    JBLeerVision.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            JBLeerVisionActionPerformed(evt);
        }
    });

    JBLeerMHistory.setBackground(new java.awt.Color(146, 154, 222));
    JBLeerMHistory.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
    JBLeerMHistory.setForeground(new java.awt.Color(255, 255, 255));
    JBLeerMHistory.setText("Leer más");
    JBLeerMHistory.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
    JBLeerMHistory.setBorderPainted(false);
    JBLeerMHistory.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            JBLeerMHistoryMouseEntered(evt);
        }
        public void mouseExited(java.awt.event.MouseEvent evt) {
            JBLeerMHistoryMouseExited(evt);
        }
    });
    JBLeerMHistory.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            JBLeerMHistoryActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout JPCuerpoLayout = new javax.swing.GroupLayout(JPCuerpo);
    JPCuerpo.setLayout(JPCuerpoLayout);
    JPCuerpoLayout.setHorizontalGroup(
        JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPCuerpoLayout.createSequentialGroup()
            .addGap(434, 434, 434)
            .addComponent(jLabel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGap(363, 363, 363))
        .addGroup(JPCuerpoLayout.createSequentialGroup()
            .addGap(75, 75, 75)
            .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(JPCuerpoLayout.createSequentialGroup()
                    .addComponent(JBLeerMHistory, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(JPCuerpoLayout.createSequentialGroup()
                    .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(20, 20, 20)))
            .addGap(10, 10, 10)
            .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(JBLeerVision, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(JPCuerpoLayout.createSequentialGroup()
                    .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(14, 14, 14)))
            .addGap(13, 13, 13))
    );
    JPCuerpoLayout.setVerticalGroup(
        JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(JPCuerpoLayout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(JPCuerpoLayout.createSequentialGroup()
                    .addGap(98, 98, 98)
                    .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(JPCuerpoLayout.createSequentialGroup()
                    .addGap(44, 44, 44)
                    .addComponent(jLabel2)))
            .addGap(34, 34, 34)
            .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(JBLeerVision, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(JBLeerMHistory, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );

    JPPiePagina.setBackground(new java.awt.Color(255, 129, 101));
    JPPiePagina.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
    JPPiePagina.setAutoscrolls(true);
    JPPiePagina.setMinimumSize(new java.awt.Dimension(1280, 200));

    jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
    jLabel5.setForeground(new java.awt.Color(255, 255, 255));
    jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel5.setText("Ponte en contacto");

    jLabel6.setBackground(new java.awt.Color(255, 255, 255));
    jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jLabel6.setForeground(new java.awt.Color(255, 255, 255));
    jLabel6.setText("123 Centro, Amayuca");

    jLabel7.setBackground(new java.awt.Color(255, 255, 255));
    jLabel7.setForeground(new java.awt.Color(255, 255, 255));
    jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/CorreoIcon.png"))); // NOI18N

    jLabel8.setBackground(new java.awt.Color(255, 255, 255));
    jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jLabel8.setForeground(new java.awt.Color(255, 255, 255));
    jLabel8.setText("735-268-29-62 ó 735-179-80-46");

    jLabel9.setBackground(new java.awt.Color(255, 255, 255));
    jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jLabel9.setForeground(new java.awt.Color(255, 255, 255));
    jLabel9.setText("RitzKeys@outlook.com");

    jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/UbicacionIcon.png"))); // NOI18N

    jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/LlamadaIcon.png"))); // NOI18N

    jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
    jLabel12.setForeground(new java.awt.Color(255, 255, 255));
    jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel12.setText("Horario");

    jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jLabel13.setForeground(new java.awt.Color(255, 255, 255));
    jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
    jLabel13.setText("<html>Puedes seguirnos en nuestras redes sociales</html>");

    jLabel15.setBackground(new java.awt.Color(255, 255, 255));
    jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
    jLabel15.setForeground(new java.awt.Color(255, 255, 255));
    jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel15.setText("<html>Lunes - Sábado<br> 12:00 PM - 7:00 PM</html>");

    jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
    jLabel14.setForeground(new java.awt.Color(255, 255, 255));
    jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    jLabel14.setText("Síguenos");

    JBTwitter.setBackground(new java.awt.Color(255, 129, 101));
    JBTwitter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon.png"))); // NOI18N
    JBTwitter.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
    JBTwitter.setContentAreaFilled(false);
    JBTwitter.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    JBTwitter.setFocusPainted(false);
    JBTwitter.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon.png"))); // NOI18N
    JBTwitter.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon2.png"))); // NOI18N
    JBTwitter.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            JBTwitterActionPerformed(evt);
        }
    });

    JBFacebook.setBackground(new java.awt.Color(255, 129, 101));
    JBFacebook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon.png"))); // NOI18N
    JBFacebook.setBorder(null);
    JBFacebook.setContentAreaFilled(false);
    JBFacebook.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    JBFacebook.setFocusPainted(false);
    JBFacebook.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon.png"))); // NOI18N
    JBFacebook.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon2.png"))); // NOI18N
    JBFacebook.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            JBFacebookActionPerformed(evt);
        }
    });

    JBInstagram.setBackground(new java.awt.Color(255, 129, 101));
    JBInstagram.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon.png"))); // NOI18N
    JBInstagram.setBorder(null);
    JBInstagram.setContentAreaFilled(false);
    JBInstagram.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    JBInstagram.setFocusPainted(false);
    JBInstagram.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon.png"))); // NOI18N
    JBInstagram.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon2.png"))); // NOI18N
    JBInstagram.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            JBInstagramActionPerformed(evt);
        }
    });

    JBYoutube.setBackground(new java.awt.Color(255, 129, 101));
    JBYoutube.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon.png"))); // NOI18N
    JBYoutube.setBorder(null);
    JBYoutube.setContentAreaFilled(false);
    JBYoutube.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    JBYoutube.setFocusPainted(false);
    JBYoutube.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon.png"))); // NOI18N
    JBYoutube.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon2.png"))); // NOI18N
    JBYoutube.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            JBYoutubeActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout JPPiePaginaLayout = new javax.swing.GroupLayout(JPPiePagina);
    JPPiePagina.setLayout(JPPiePaginaLayout);
    JPPiePaginaLayout.setHorizontalGroup(
        JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(JPPiePaginaLayout.createSequentialGroup()
            .addGap(20, 20, 20)
            .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel10)
                .addComponent(jLabel7)
                .addComponent(jLabel11))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel6)
                .addComponent(jLabel5)
                .addComponent(jLabel8)
                .addComponent(jLabel9))
            .addGap(59, 59, 59)
            .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(JPPiePaginaLayout.createSequentialGroup()
                    .addGap(30, 30, 30)
                    .addComponent(jLabel14)
                    .addGap(49, 49, 49)
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(JPPiePaginaLayout.createSequentialGroup()
                            .addGap(92, 92, 92)
                            .addComponent(jLabel12))
                        .addGroup(JPPiePaginaLayout.createSequentialGroup()
                            .addGap(63, 63, 63)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addComponent(JBTwitter)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JBFacebook)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JBInstagram)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(JBYoutube))))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    JPPiePaginaLayout.setVerticalGroup(
        JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(JPPiePaginaLayout.createSequentialGroup()
            .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(JPPiePaginaLayout.createSequentialGroup()
                    .addGap(25, 25, 25)
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel10)
                        .addGroup(JPPiePaginaLayout.createSequentialGroup()
                            .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(jLabel14))
                            .addGap(18, 18, 18)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel11)
                        .addGroup(JPPiePaginaLayout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(JPPiePaginaLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(10, 10, 10)
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(JBTwitter, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(JBFacebook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(JBYoutube, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addGroup(JPPiePaginaLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(JBInstagram))
                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JPPiePaginaLayout.createSequentialGroup()
                    .addGap(26, 26, 26)
                    .addComponent(jLabel12)))
            .addContainerGap())
    );

    javax.swing.GroupLayout JPPrincipalSCLayout = new javax.swing.GroupLayout(JPPrincipalSC);
    JPPrincipalSC.setLayout(JPPrincipalSCLayout);
    JPPrincipalSCLayout.setHorizontalGroup(
        JPPrincipalSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(JPCabezera, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        .addGroup(JPPrincipalSCLayout.createSequentialGroup()
            .addComponent(JPCuerpo, javax.swing.GroupLayout.DEFAULT_SIZE, 1269, Short.MAX_VALUE)
            .addGap(1, 1, 1))
        .addGroup(JPPrincipalSCLayout.createSequentialGroup()
            .addComponent(JPPiePagina, javax.swing.GroupLayout.PREFERRED_SIZE, 1269, Short.MAX_VALUE)
            .addGap(1, 1, 1))
    );
    JPPrincipalSCLayout.setVerticalGroup(
        JPPrincipalSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPPrincipalSCLayout.createSequentialGroup()
            .addComponent(JPCabezera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE)
            .addComponent(JPCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 696, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(JPPiePagina, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, 0))
    );

    jScrollPane1.setViewportView(JPPrincipalSC);

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
    this.setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );
    }// </editor-fold>//GEN-END:initComponents

    private void JBMenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBMenuMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_JBMenuMouseClicked

    private void JBMenuMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBMenuMouseEntered
        JBMenu.setBackground(new Color(51,153,255));
    }//GEN-LAST:event_JBMenuMouseEntered

    private void JBMenuMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBMenuMouseExited
        JBMenu.setBackground(Color.WHITE);
    }//GEN-LAST:event_JBMenuMouseExited

    private void JBMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBMenuActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new MenuPagina(JPPrincipal);
    }//GEN-LAST:event_JBMenuActionPerformed

    private void JBCarritoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCarritoMouseEntered
        JBCarrito.setBorder(new LineBorder(Color.BLACK));
    }//GEN-LAST:event_JBCarritoMouseEntered

    private void JBCarritoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCarritoMouseExited
        JBCarrito.setBorder(null);
    }//GEN-LAST:event_JBCarritoMouseExited

    private void JBCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBCarritoActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        CarritoPagina carrito = new CarritoPagina(JPPrincipal);
    }//GEN-LAST:event_JBCarritoActionPerformed

    private void JBUsuarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBUsuarioMouseEntered
        JBUsuario.setBorder(new LineBorder(Color.BLACK));
    }//GEN-LAST:event_JBUsuarioMouseEntered

    private void JBUsuarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBUsuarioMouseExited
        JBUsuario.setBorder(null);
    }//GEN-LAST:event_JBUsuarioMouseExited

    private void JBUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBUsuarioActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new UsuarioPagina(JPPrincipal);
    }//GEN-LAST:event_JBUsuarioActionPerformed

    private void JBTwitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTwitterActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://twitter.com/?lang=es"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBTwitterActionPerformed

    private void JBFacebookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBFacebookActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.facebook.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBFacebookActionPerformed

    private void JBInstagramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBInstagramActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.instagram.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBInstagramActionPerformed

    private void JBYoutubeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBYoutubeActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.youtube.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBYoutubeActionPerformed

    private void JBInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBInicioActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new PaginaInicio(JPPrincipal);
    }//GEN-LAST:event_JBInicioActionPerformed

    private void JBInicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBInicioMouseEntered
       JBInicio.setBackground(new Color(51,153,255));
    }//GEN-LAST:event_JBInicioMouseEntered

    private void JBInicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBInicioMouseExited
        JBInicio.setBackground(null);
    }//GEN-LAST:event_JBInicioMouseExited

    private void JBLeerMHistoryMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBLeerMHistoryMouseExited
     JBLeerMHistory.setBackground(new Color(146,154,222));
    }//GEN-LAST:event_JBLeerMHistoryMouseExited

    private void JBLeerVisionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBLeerVisionMouseEntered
     JBLeerVision.setBackground(new Color(146,184,222));
    }//GEN-LAST:event_JBLeerVisionMouseEntered

    private void JBLeerVisionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBLeerVisionMouseExited
     JBLeerVision.setBackground(new Color(146,154,222));
    }//GEN-LAST:event_JBLeerVisionMouseExited

    private void JBLeerMHistoryMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBLeerMHistoryMouseEntered
       JBLeerMHistory.setBackground(new Color(146,184,222));
    }//GEN-LAST:event_JBLeerMHistoryMouseEntered

    private void JBTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTituloActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new PaginaInicio(JPPrincipal);
    }//GEN-LAST:event_JBTituloActionPerformed

    private void JBLeerMHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBLeerMHistoryActionPerformed
   JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new Historia(JPPrincipal);
    }//GEN-LAST:event_JBLeerMHistoryActionPerformed

    private void JBLeerVisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBLeerVisionActionPerformed
      JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new Vision(JPPrincipal);
    }//GEN-LAST:event_JBLeerVisionActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton JBAcerca;
    private javax.swing.JButton JBCarrito;
    private javax.swing.JButton JBFacebook;
    private javax.swing.JButton JBInicio;
    private javax.swing.JButton JBInstagram;
    private javax.swing.JButton JBLeerMHistory;
    private javax.swing.JButton JBLeerVision;
    private javax.swing.JButton JBMenu;
    private javax.swing.JButton JBTitulo;
    private javax.swing.JButton JBTwitter;
    private javax.swing.JButton JBUsuario;
    private javax.swing.JButton JBYoutube;
    private javax.swing.JLabel JLNotificación;
    private javax.swing.JPanel JPCabezera;
    private javax.swing.JPanel JPCuerpo;
    private javax.swing.JPanel JPPiePagina;
    private javax.swing.JPanel JPPrincipalSC;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
