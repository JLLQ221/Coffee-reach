/**
 *@author Jael Pineda Quiroz
 * Copyright (c) 2020 Todos los derechos reservados.
 */


package IngenieriaSF;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

class Orden {

    String imagen, nombre;
    int cantidad, precioUnidad, totalPagar;
    ConexiónBD conexion = new ConexiónBD();
    
    public void setInfor(String imagen, String nombre, int cantidad, int precioUnidad) {  
        conexion.conectar();
        this.imagen = imagen;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precioUnidad = precioUnidad;
        this.totalPagar = this.cantidad * precioUnidad;
        
        conexion.consultaDato("cliente",new String[]{"Correo"}, new String[]{"jael@outlook.com"}, "ClienteID");
        ResultSet relCliente = conexion.rel;
        
        conexion.consultaDato("productos",new String[]{"Imagen"}, new String[]{imagen}, "ProductoID");
        ResultSet relProducto = conexion.rel;
         
        try {
            conexion.insertarDatos("orden",String.format("NULL, '%s', NULL, NOW(), NULL, %s, %s, '%s', '%s'", imagen, cantidad, totalPagar, relCliente.getString("ClienteID"), relProducto.getString("ProductoID")));
        } catch (SQLException ex) {
            Logger.getLogger(Orden.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}