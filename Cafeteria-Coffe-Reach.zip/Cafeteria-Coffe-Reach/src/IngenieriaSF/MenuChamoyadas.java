
package IngenieriaSF;

import java.awt.Color;
import java.awt.Desktop;
import java.io.File;
import java.net.URI;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.border.LineBorder;

/**
 *
 * @author Jael Pineda Quiroz
 */
public class MenuChamoyadas extends javax.swing.JPanel {
    String nombre, imagen;
    int cantidad = 0, valorTotal = 0, valorUnidad = 0, productoAgregadoIndex = 0;
    JPanel JPPrincipal;
    Orden orden = new Orden();
    ConexiónBD conexion = new ConexiónBD();
    

    /**
     * Creates new form MenuPAgina
     */
    public MenuChamoyadas(JPanel panelPrincipal) {
        conexion.conectar();
        initComponents();
        this.JPPrincipal = panelPrincipal;
        JPPrincipal.add(this);
        obtenerProductos();
        carritoIndex();
    }
    
      private void obtenerProductos() {
           JLabel labelsProductos[] = {JLTituloFrappe1, JLDescripciónFrappe1, JLTituloFrappe2 , JLDescripciónFrappe2};
           JLabel imagenesProductos[] = { JLImagenFrappe1 ,  JLImagenFrappe2};
          try {
               conexion.consultaTablaCompleta("productos", "tipo = 'Chamoyadas'");
               ResultSet rel = conexion.rel;
               int contador = 0 , contadorImagen = 0; 
               while (rel.next()) {
                  String datos[] = {rel.getString("Imagen"), rel.getString("Nombre"),rel.getString("Descripcion"),String.valueOf(rel.getInt("Precio"))};
                   for (int i = 0; i < 2; i++) {
                       labelsProductos[contador].setText(String.format("<html>%s<html>", datos[i+1]));
                       contador++;
                   }
                     imagenesProductos[contadorImagen].setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesMenuFrappés/" + datos[0])));
                     contadorImagen++;
              }  
              
          } catch (Exception e) {
          }         
    }
      public void carritoIndex(){
             int carrito = conexion.conteoCarrito("orden", "82cedc8f-1ba9-11ef-bc9e-d4939021fdda"); 
             JLNotificación.setText(String.format("%d", carrito));
             this.revalidate();
      }

    public void obtenerValores(int index) {
        JLabel labelsProductos[] = {JLImagenFrappe1, JLTituloFrappe1, JLImagenFrappe2, JLTituloFrappe2};
        JSpinner spinnerProducto[] = {JSFrape1, JSFrape2};
        File ruta = new File(labelsProductos[(index - 1) * 2].getIcon().toString()); 
        imagen = ruta.getName();
        nombre = labelsProductos[(index * 2) - 1].getText();
        cantidad = (Integer) spinnerProducto[index - 1].getValue();
        valorUnidad = 35;
        agregarProducto(imagen, nombre, cantidad, valorUnidad, productoAgregadoIndex);
    }

    public void agregarProducto(String imagen, String nombre, int cantidad, int valorUnidad, int index) {
       orden.setInfor(imagen, nombre, cantidad, valorUnidad);
       carritoIndex();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        JPPrincipalSC = new javax.swing.JPanel();
        JPCabezera = new javax.swing.JPanel();
        JBInicio = new javax.swing.JButton();
        JBAcerca = new javax.swing.JButton();
        JBMenu = new javax.swing.JButton();
        JBTitulo = new javax.swing.JButton();
        JBCarrito = new javax.swing.JButton();
        JBUsuario = new javax.swing.JButton();
        JLNotificación = new javax.swing.JLabel();
        JPCuerpo = new javax.swing.JPanel();
        JBFrappes = new javax.swing.JButton();
        JBChamoyadas = new javax.swing.JButton();
        JBCafesHelados = new javax.swing.JButton();
        JBBebidasCalientes = new javax.swing.JButton();
        JBSmoothies = new javax.swing.JButton();
        JSFrape1 = new javax.swing.JSpinner();
        JLImagenFrappe1 = new javax.swing.JLabel();
        JLTituloFrappe1 = new javax.swing.JLabel();
        JLDescripciónFrappe1 = new javax.swing.JLabel();
        AñadirFrape1 = new javax.swing.JButton();
        JLImagenFrappe2 = new javax.swing.JLabel();
        JLTituloFrappe2 = new javax.swing.JLabel();
        JLDescripciónFrappe2 = new javax.swing.JLabel();
        JSFrape2 = new javax.swing.JSpinner();
        AñadirFrape2 = new javax.swing.JButton();
        JPPiePagina = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        JBTwitter = new javax.swing.JButton();
        JBFacebook = new javax.swing.JButton();
        JBInstagram = new javax.swing.JButton();
        JBYoutube = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1280, 700));
        setPreferredSize(new java.awt.Dimension(1280, 700));

        jScrollPane1.setBorder(null);
        jScrollPane1.setAutoscrolls(true);
        jScrollPane1.setDoubleBuffered(true);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(1280, 700));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(1280, 700));

        JPPrincipalSC.setBackground(new java.awt.Color(255, 255, 255));
        JPPrincipalSC.setForeground(new java.awt.Color(255, 255, 255));
        JPPrincipalSC.setAutoscrolls(true);
        JPPrincipalSC.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        JPPrincipalSC.setMinimumSize(new java.awt.Dimension(1260, 960));
        JPPrincipalSC.setPreferredSize(new java.awt.Dimension(1260, 960));

        JPCabezera.setBackground(new java.awt.Color(255, 255, 255));
        JPCabezera.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        JPCabezera.setMinimumSize(new java.awt.Dimension(1260, 65));
        JPCabezera.setPreferredSize(new java.awt.Dimension(1270, 65));

        JBInicio.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBInicio.setText("Inicio");
        JBInicio.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JBInicio.setBorderPainted(false);
        JBInicio.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBInicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBInicioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBInicioMouseExited(evt);
            }
        });
        JBInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBInicioActionPerformed(evt);
            }
        });

        JBAcerca.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBAcerca.setText("Acerca");
        JBAcerca.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JBAcerca.setBorderPainted(false);
        JBAcerca.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBAcerca.setDoubleBuffered(true);
        JBAcerca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBAcercaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBAcercaMouseExited(evt);
            }
        });
        JBAcerca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBAcercaActionPerformed(evt);
            }
        });

        JBMenu.setBackground(new java.awt.Color(51, 153, 255));
        JBMenu.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBMenu.setText("Menú");
        JBMenu.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        JBMenu.setBorderPainted(false);
        JBMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBMenu.setDoubleBuffered(true);
        JBMenu.setSelected(true);
        JBMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBMenuActionPerformed(evt);
            }
        });

        JBTitulo.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        JBTitulo.setText("RITZKEY'S");
        JBTitulo.setBorder(null);
        JBTitulo.setBorderPainted(false);
        JBTitulo.setContentAreaFilled(false);
        JBTitulo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBTitulo.setDefaultCapable(false);
        JBTitulo.setFocusable(false);
        JBTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTituloActionPerformed(evt);
            }
        });

        JBCarrito.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesPgInicio/carroCompraIcon.png"))); // NOI18N
        JBCarrito.setBorder(null);
        JBCarrito.setContentAreaFilled(false);
        JBCarrito.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBCarrito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBCarritoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBCarritoMouseExited(evt);
            }
        });
        JBCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBCarritoActionPerformed(evt);
            }
        });

        JBUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesPgInicio/usuarioIcon.png"))); // NOI18N
        JBUsuario.setBorder(null);
        JBUsuario.setContentAreaFilled(false);
        JBUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBUsuarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBUsuarioMouseExited(evt);
            }
        });
        JBUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBUsuarioActionPerformed(evt);
            }
        });

        JLNotificación.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JLNotificación.setForeground(new java.awt.Color(255, 255, 255));
        JLNotificación.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLNotificación.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/circuloIcon.png"))); // NOI18N
        JLNotificación.setText("0");
        JLNotificación.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout JPCabezeraLayout = new javax.swing.GroupLayout(JPCabezera);
        JPCabezera.setLayout(JPCabezeraLayout);
        JPCabezeraLayout.setHorizontalGroup(
            JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JBTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(347, 347, 347)
                .addComponent(JBInicio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(JBAcerca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(JBMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(350, 350, 350)
                .addComponent(JBUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(JBCarrito)
                .addGap(0, 0, 0)
                .addComponent(JLNotificación)
                .addGap(20, 20, 20))
        );
        JPCabezeraLayout.setVerticalGroup(
            JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addComponent(JBTitulo)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JLNotificación)
                    .addComponent(JBUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBAcerca, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        JPCuerpo.setBackground(new java.awt.Color(255, 255, 255));
        JPCuerpo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        JPCuerpo.setMinimumSize(new java.awt.Dimension(1260, 1008));
        JPCuerpo.setPreferredSize(new java.awt.Dimension(1260, 512));

        JBFrappes.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JBFrappes.setText("Frappés");
        JBFrappes.setBorder(null);
        JBFrappes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBFrappes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBFrappesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBFrappesMouseExited(evt);
            }
        });
        JBFrappes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBFrappesActionPerformed(evt);
            }
        });

        JBChamoyadas.setBackground(new java.awt.Color(51, 153, 255));
        JBChamoyadas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JBChamoyadas.setText("Chamoyadas");
        JBChamoyadas.setBorder(null);
        JBChamoyadas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBChamoyadas.setSelected(true);
        JBChamoyadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBChamoyadasActionPerformed(evt);
            }
        });

        JBCafesHelados.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JBCafesHelados.setText("Cafés helados");
        JBCafesHelados.setBorder(null);
        JBCafesHelados.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBCafesHelados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBCafesHeladosMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBCafesHeladosMouseExited(evt);
            }
        });
        JBCafesHelados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBCafesHeladosActionPerformed(evt);
            }
        });

        JBBebidasCalientes.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JBBebidasCalientes.setText("Bebidas calientes");
        JBBebidasCalientes.setBorder(null);
        JBBebidasCalientes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBBebidasCalientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBBebidasCalientesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBBebidasCalientesMouseExited(evt);
            }
        });
        JBBebidasCalientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBBebidasCalientesActionPerformed(evt);
            }
        });

        JBSmoothies.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JBSmoothies.setText("Smoothies");
        JBSmoothies.setBorder(null);
        JBSmoothies.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBSmoothies.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBSmoothiesMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBSmoothiesMouseExited(evt);
            }
        });
        JBSmoothies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBSmoothiesActionPerformed(evt);
            }
        });

        JSFrape1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JSFrape1.setModel(new javax.swing.SpinnerNumberModel(1, 1, 10, 1));
        JSFrape1.setName(""); // NOI18N

        JLImagenFrappe1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesMenuFrappés/MangonadaImg.png"))); // NOI18N

        JLTituloFrappe1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        JLTituloFrappe1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        JLTituloFrappe1.setText("Mangonada");

        JLDescripciónFrappe1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JLDescripciónFrappe1.setText("<html>Prueba nuestro deliciosa Mangonada,<br>" +
            "hecho con los mejores ingredientes de la<br>" +
            "zona.</html>");

        AñadirFrape1.setBackground(new java.awt.Color(255, 204, 51));
        AñadirFrape1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AñadirFrape1.setText("Añadir");
        AñadirFrape1.setBorder(null);
        AñadirFrape1.setFocusable(false);
        AñadirFrape1.setRolloverEnabled(false);
        AñadirFrape1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AñadirFrape1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                AñadirFrape1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                AñadirFrape1MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                AñadirFrape1MouseReleased(evt);
            }
        });
        AñadirFrape1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñadirFrape1ActionPerformed(evt);
            }
        });

        JLImagenFrappe2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesMenuFrappés/FresadaImg.png"))); // NOI18N

        JLTituloFrappe2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        JLTituloFrappe2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        JLTituloFrappe2.setText("Fresada");

        JLDescripciónFrappe2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JLDescripciónFrappe2.setText("<html>Prueba nuestra deliciosa Fresada,<br>" +
            "hecho jugo de naranja, jugo de limón<br>" +
            "jugo de toronja y las más frescas fresas.<html>");

        JSFrape2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JSFrape2.setModel(new javax.swing.SpinnerNumberModel(1, 1, 10, 1));
        JSFrape2.setDoubleBuffered(true);
        JSFrape2.setEditor(new javax.swing.JSpinner.NumberEditor(JSFrape2, ""));
        JSFrape2.setName(""); // NOI18N

        AñadirFrape2.setBackground(new java.awt.Color(255, 204, 51));
        AñadirFrape2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        AñadirFrape2.setText("Añadir");
        AñadirFrape2.setBorderPainted(false);
        AñadirFrape2.setFocusable(false);
        AñadirFrape2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                AñadirFrape2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                AñadirFrape2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                AñadirFrape2MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                AñadirFrape2MouseReleased(evt);
            }
        });
        AñadirFrape2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AñadirFrape2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPCuerpoLayout = new javax.swing.GroupLayout(JPCuerpo);
        JPCuerpo.setLayout(JPCuerpoLayout);
        JPCuerpoLayout.setHorizontalGroup(
            JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCuerpoLayout.createSequentialGroup()
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGap(270, 270, 270)
                        .addComponent(JBFrappes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(0, 0, 0)
                        .addComponent(JBChamoyadas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(0, 0, 0)
                        .addComponent(JBCafesHelados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(JLImagenFrappe1)
                        .addGap(18, 18, 18)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addComponent(JLTituloFrappe1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(151, 151, 151))
                            .addComponent(JLDescripciónFrappe1, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGap(205, 205, 205)
                        .addComponent(JLImagenFrappe2)
                        .addGap(18, 18, 18)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addComponent(JLTituloFrappe2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(131, 131, 131))
                            .addComponent(JLDescripciónFrappe2, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(60, 60, 60)))
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addComponent(JBBebidasCalientes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(0, 0, 0)
                        .addComponent(JBSmoothies, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(229, 229, 229))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JSFrape2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JSFrape1))
                        .addGap(59, 59, 59)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(AñadirFrape1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(AñadirFrape2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(232, 232, 232))))
        );
        JPCuerpoLayout.setVerticalGroup(
            JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCuerpoLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JBSmoothies, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBFrappes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBChamoyadas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBCafesHelados, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JBBebidasCalientes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JSFrape1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AñadirFrape1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(150, 150, 150)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(JSFrape2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AñadirFrape2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(JLTituloFrappe1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(JLDescripciónFrappe1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JPCuerpoLayout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(JLImagenFrappe1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(33, 33, 33)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(JLImagenFrappe2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addComponent(JLTituloFrappe2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(JLDescripciónFrappe2, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        JPPiePagina.setBackground(new java.awt.Color(255, 129, 101));
        JPPiePagina.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        JPPiePagina.setAutoscrolls(true);
        JPPiePagina.setMinimumSize(new java.awt.Dimension(1280, 200));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Ponte en contacto");

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("123 Centro, Amayuca");

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/CorreoIcon.png"))); // NOI18N

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("735-268-29-62 ó 735-179-80-46");

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("RitzKeys@outlook.com");

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/UbicacionIcon.png"))); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/LlamadaIcon.png"))); // NOI18N

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Horario");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setText("<html>Puedes seguirnos en nuestras redes sociales</html>");

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("<html>Lunes - Sábado<br> 12:00 PM - 7:00 PM</html>");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Síguenos");

        JBTwitter.setBackground(new java.awt.Color(255, 129, 101));
        JBTwitter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon.png"))); // NOI18N
        JBTwitter.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        JBTwitter.setContentAreaFilled(false);
        JBTwitter.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBTwitter.setFocusPainted(false);
        JBTwitter.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon.png"))); // NOI18N
        JBTwitter.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon2.png"))); // NOI18N
        JBTwitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTwitterActionPerformed(evt);
            }
        });

        JBFacebook.setBackground(new java.awt.Color(255, 129, 101));
        JBFacebook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon.png"))); // NOI18N
        JBFacebook.setBorder(null);
        JBFacebook.setContentAreaFilled(false);
        JBFacebook.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBFacebook.setFocusPainted(false);
        JBFacebook.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon.png"))); // NOI18N
        JBFacebook.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon2.png"))); // NOI18N
        JBFacebook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBFacebookActionPerformed(evt);
            }
        });

        JBInstagram.setBackground(new java.awt.Color(255, 129, 101));
        JBInstagram.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon.png"))); // NOI18N
        JBInstagram.setBorder(null);
        JBInstagram.setContentAreaFilled(false);
        JBInstagram.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBInstagram.setFocusPainted(false);
        JBInstagram.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon.png"))); // NOI18N
        JBInstagram.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon2.png"))); // NOI18N
        JBInstagram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBInstagramActionPerformed(evt);
            }
        });

        JBYoutube.setBackground(new java.awt.Color(255, 129, 101));
        JBYoutube.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon.png"))); // NOI18N
        JBYoutube.setBorder(null);
        JBYoutube.setContentAreaFilled(false);
        JBYoutube.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBYoutube.setFocusPainted(false);
        JBYoutube.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon.png"))); // NOI18N
        JBYoutube.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon2.png"))); // NOI18N
        JBYoutube.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBYoutubeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPPiePaginaLayout = new javax.swing.GroupLayout(JPPiePagina);
        JPPiePagina.setLayout(JPPiePaginaLayout);
        JPPiePaginaLayout.setHorizontalGroup(
            JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel7)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGap(59, 59, 59)
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel14)
                        .addGap(49, 49, 49)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addGap(92, 92, 92)
                                .addComponent(jLabel12))
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addGap(63, 63, 63)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(JPPiePaginaLayout.createSequentialGroup()
                            .addComponent(JBTwitter)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JBFacebook)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JBInstagram)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JBYoutube))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JPPiePaginaLayout.setVerticalGroup(
            JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel14))
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11)
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(JBTwitter, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JBFacebook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(JBYoutube, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(JBInstagram))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JPPiePaginaLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel12)))
                .addContainerGap())
        );

        javax.swing.GroupLayout JPPrincipalSCLayout = new javax.swing.GroupLayout(JPPrincipalSC);
        JPPrincipalSC.setLayout(JPPrincipalSCLayout);
        JPPrincipalSCLayout.setHorizontalGroup(
            JPPrincipalSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JPCabezera, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPPrincipalSCLayout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(JPPiePagina, javax.swing.GroupLayout.PREFERRED_SIZE, 1268, Short.MAX_VALUE)
                .addGap(1, 1, 1))
            .addGroup(JPPrincipalSCLayout.createSequentialGroup()
                .addComponent(JPCuerpo, javax.swing.GroupLayout.DEFAULT_SIZE, 1264, Short.MAX_VALUE)
                .addGap(6, 6, 6))
        );
        JPPrincipalSCLayout.setVerticalGroup(
            JPPrincipalSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPPrincipalSCLayout.createSequentialGroup()
                .addComponent(JPCabezera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(JPCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 696, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JPPiePagina, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jScrollPane1.setViewportView(JPPrincipalSC);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void JBInicioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBInicioMouseEntered
        JBInicio.setBackground(new Color(51, 153, 255));
    }//GEN-LAST:event_JBInicioMouseEntered

    private void JBInicioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBInicioMouseExited
        JBInicio.setBackground(null);
    }//GEN-LAST:event_JBInicioMouseExited

    private void JBInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBInicioActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new PaginaInicio(JPPrincipal);
    }//GEN-LAST:event_JBInicioActionPerformed

    private void JBAcercaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBAcercaMouseEntered
        JBAcerca.setBackground(new Color(51, 153, 255));        // TODO add your handling code here:
    }//GEN-LAST:event_JBAcercaMouseEntered

    private void JBAcercaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBAcercaMouseExited
        JBAcerca.setBackground(null);
    }//GEN-LAST:event_JBAcercaMouseExited

    private void JBAcercaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBAcercaActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.repaint();
        JPPrincipal.revalidate();
        new AcercaPagina(JPPrincipal);
    }//GEN-LAST:event_JBAcercaActionPerformed

    private void JBMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBMenuActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new MenuPagina(JPPrincipal);
    }//GEN-LAST:event_JBMenuActionPerformed

    private void JBTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTituloActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new PaginaInicio(JPPrincipal);
    }//GEN-LAST:event_JBTituloActionPerformed

    private void JBCarritoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCarritoMouseEntered
        JBCarrito.setBorder(new LineBorder(Color.BLACK));
    }//GEN-LAST:event_JBCarritoMouseEntered

    private void JBCarritoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCarritoMouseExited
        JBCarrito.setBorder(null);
    }//GEN-LAST:event_JBCarritoMouseExited

    private void JBCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBCarritoActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        CarritoPagina carrito = new CarritoPagina(JPPrincipal);     
    }//GEN-LAST:event_JBCarritoActionPerformed

    private void JBUsuarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBUsuarioMouseEntered
        JBUsuario.setBorder(new LineBorder(Color.BLACK));
    }//GEN-LAST:event_JBUsuarioMouseEntered

    private void JBUsuarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBUsuarioMouseExited
        JBUsuario.setBorder(null);
    }//GEN-LAST:event_JBUsuarioMouseExited

    private void JBUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBUsuarioActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new UsuarioPagina(JPPrincipal);
    }//GEN-LAST:event_JBUsuarioActionPerformed

    private void JBTwitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTwitterActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://twitter.com/?lang=es"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBTwitterActionPerformed

    private void JBFacebookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBFacebookActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.facebook.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBFacebookActionPerformed

    private void JBInstagramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBInstagramActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.instagram.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBInstagramActionPerformed

    private void JBYoutubeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBYoutubeActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.youtube.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBYoutubeActionPerformed

    private void AñadirFrape2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñadirFrape2ActionPerformed
        obtenerValores(2);
    }//GEN-LAST:event_AñadirFrape2ActionPerformed

    private void AñadirFrape2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape2MouseReleased
        AñadirFrape2.setBackground(new Color(255, 220, 51));
    }//GEN-LAST:event_AñadirFrape2MouseReleased

    private void AñadirFrape2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape2MousePressed
        AñadirFrape2.setBackground(new Color(204, 164, 42));
    }//GEN-LAST:event_AñadirFrape2MousePressed

    private void AñadirFrape2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape2MouseExited
        AñadirFrape2.setBackground(new Color(255, 204, 51));
    }//GEN-LAST:event_AñadirFrape2MouseExited

    private void AñadirFrape2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape2MouseEntered
        AñadirFrape2.setBackground(new Color(254, 228, 95));
    }//GEN-LAST:event_AñadirFrape2MouseEntered

    private void AñadirFrape1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AñadirFrape1ActionPerformed
        obtenerValores(1);
    }//GEN-LAST:event_AñadirFrape1ActionPerformed

    private void AñadirFrape1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape1MouseReleased
        AñadirFrape1.setBackground(new Color(255, 220, 51));
    }//GEN-LAST:event_AñadirFrape1MouseReleased

    private void AñadirFrape1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape1MousePressed
        AñadirFrape1.setBackground(new Color(204, 164, 42));
    }//GEN-LAST:event_AñadirFrape1MousePressed

    private void AñadirFrape1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape1MouseExited
        AñadirFrape1.setBackground(new Color(255, 204, 51));
    }//GEN-LAST:event_AñadirFrape1MouseExited

    private void AñadirFrape1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AñadirFrape1MouseEntered
        AñadirFrape1.setBackground(new Color(254, 228, 95));
    }//GEN-LAST:event_AñadirFrape1MouseEntered

    private void JBSmoothiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBSmoothiesActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new MenuSmoothies(JPPrincipal);
    }//GEN-LAST:event_JBSmoothiesActionPerformed

    private void JBSmoothiesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBSmoothiesMouseExited
        JBSmoothies.setBackground(Color.WHITE);
    }//GEN-LAST:event_JBSmoothiesMouseExited

    private void JBSmoothiesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBSmoothiesMouseEntered
        JBSmoothies.setBackground(new Color(51, 153, 255));
    }//GEN-LAST:event_JBSmoothiesMouseEntered

    private void JBBebidasCalientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBBebidasCalientesActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new MenuBebidasCalientes(JPPrincipal);
    }//GEN-LAST:event_JBBebidasCalientesActionPerformed

    private void JBBebidasCalientesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBBebidasCalientesMouseExited
        JBBebidasCalientes.setBackground(Color.WHITE);
    }//GEN-LAST:event_JBBebidasCalientesMouseExited

    private void JBBebidasCalientesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBBebidasCalientesMouseEntered
        JBBebidasCalientes.setBackground(new Color(51, 153, 255));
    }//GEN-LAST:event_JBBebidasCalientesMouseEntered

    private void JBCafesHeladosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBCafesHeladosActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new MenuCafesHelados(JPPrincipal);
    }//GEN-LAST:event_JBCafesHeladosActionPerformed

    private void JBCafesHeladosMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCafesHeladosMouseExited
        JBCafesHelados.setBackground(Color.WHITE);
    }//GEN-LAST:event_JBCafesHeladosMouseExited

    private void JBCafesHeladosMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCafesHeladosMouseEntered
        JBCafesHelados.setBackground(new Color(51, 153, 255));
    }//GEN-LAST:event_JBCafesHeladosMouseEntered

    private void JBChamoyadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBChamoyadasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JBChamoyadasActionPerformed

    private void JBFrappesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBFrappesActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new MenuPagina(JPPrincipal);
    }//GEN-LAST:event_JBFrappesActionPerformed

    private void JBFrappesMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBFrappesMouseExited
        JBFrappes.setBackground(Color.WHITE);
    }//GEN-LAST:event_JBFrappesMouseExited

    private void JBFrappesMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBFrappesMouseEntered
        JBFrappes.setBackground(new Color(51, 153, 255));
    }//GEN-LAST:event_JBFrappesMouseEntered


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AñadirFrape1;
    private javax.swing.JButton AñadirFrape2;
    private javax.swing.JButton JBAcerca;
    private javax.swing.JButton JBBebidasCalientes;
    private javax.swing.JButton JBCafesHelados;
    private javax.swing.JButton JBCarrito;
    private javax.swing.JButton JBChamoyadas;
    private javax.swing.JButton JBFacebook;
    private javax.swing.JButton JBFrappes;
    private javax.swing.JButton JBInicio;
    private javax.swing.JButton JBInstagram;
    private javax.swing.JButton JBMenu;
    private javax.swing.JButton JBSmoothies;
    private javax.swing.JButton JBTitulo;
    private javax.swing.JButton JBTwitter;
    private javax.swing.JButton JBUsuario;
    private javax.swing.JButton JBYoutube;
    private javax.swing.JLabel JLDescripciónFrappe1;
    private javax.swing.JLabel JLDescripciónFrappe2;
    private javax.swing.JLabel JLImagenFrappe1;
    private javax.swing.JLabel JLImagenFrappe2;
    private javax.swing.JLabel JLNotificación;
    private javax.swing.JLabel JLTituloFrappe1;
    private javax.swing.JLabel JLTituloFrappe2;
    private javax.swing.JPanel JPCabezera;
    private javax.swing.JPanel JPCuerpo;
    private javax.swing.JPanel JPPiePagina;
    private javax.swing.JPanel JPPrincipalSC;
    private javax.swing.JSpinner JSFrape1;
    private javax.swing.JSpinner JSFrape2;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
