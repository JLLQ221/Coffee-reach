package IngenieriaSF;

import java.awt.Color;
import java.awt.Desktop;
import java.net.URI;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.border.LineBorder;

/**
 *
 * @author Jael Pineda Quiroz
 */
public class CarritoPagina extends javax.swing.JPanel {

    JPanel JPPrincipal;
    String cupon;
    ConexiónBD conexion = new ConexiónBD();
    int productoAgregadoIndex = 0;

    /**
     * Creates new form CarritoPágina
     */
    public CarritoPagina(JPanel panelPrincipal) {
        conexion.conectar();
        initComponents();
        mandarVisible(3, false);
        this.JPPrincipal = panelPrincipal;
        JPPrincipal.add(this);
        carritoIndex();
        llenarLabels();
    }

    public void carritoIndex() {
        ConexiónBD conexion = new ConexiónBD();
        conexion.conectar();
        int carrito = conexion.conteoCarrito("orden", "82cedc8f-1ba9-11ef-bc9e-d4939021fdda");
        JLNotificación.setText(String.format("%d", carrito));
        JPCabezera.revalidate();
        JPCabezera.repaint();
        this.repaint();
        this.revalidate();
        conexion.desconectar();
    }

    public void mandarVisible(int index, boolean invisible) {
        JButton butonesEliminar[] = {BTEliminarPedido1, BTEliminarPedido2, BTEliminarPedido3};
        JSpinner spinnerCantidad[] = {JSCantidadPedido1, JSCantidadPedido2, JSCantidadPedido3};
        for (int i = 0; i < index; i++) {
            butonesEliminar[i].setVisible(invisible);
            spinnerCantidad[i].setVisible(invisible);
        }
    }

    public void limpiarLabels() {
        JLabel labelsPedido[] = {JLImgPedido1, JLTituloPedido1, JLPagoPedido1, JLImgPedido2, JLTituloPedido2, JLPagoPedido2, JLImgPedido3, JLTituloPedido3, JLPagoPedido3};
        for (int i = 0; i < labelsPedido.length; i++) {
            if (i < 3) {
                labelsPedido[i * 3].setIcon(null);
            }
            labelsPedido[i].setText("");
        }
        mandarVisible(3, false);
    }

    private void llenarLabels() {
        JLabel labelsPedido[] = {JLTituloPedido1, JLPagoPedido1, JLTituloPedido2, JLPagoPedido2, JLTituloPedido3, JLPagoPedido3};
        JLabel imagenesProductos[] = {JLImgPedido1, JLImgPedido2, JLImgPedido3};
        JSpinner spinnerCantidad[] = {JSCantidadPedido1, JSCantidadPedido2, JSCantidadPedido3};
        conexion.consultaWhere("orden", "ClienteID", "82cedc8f-1ba9-11ef-bc9e-d4939021fdda");
        ResultSet rel = conexion.rel;
        int contador = 0, contadorImagen = 0;
        try {
            if (Integer.valueOf(JLNotificación.getText()) == 1) {
                conexion.consultaDato("productos", new String[]{"ProductoID"}, new String[]{rel.getString("ProductoID")}, "Nombre");
                ResultSet relNombre = conexion.rel;
                String datos[] = {rel.getString("Imagen"), relNombre.getString("Nombre"), String.valueOf(rel.getInt("TotalPago"))};
                for (int i = 0; i < 2; i++) {
                    labelsPedido[contador].setText(String.format("<html>%s<html>", datos[i + 1]));
                    contador++;
                }
                conexion.consultaDato("productos", new String[]{"ProductoID"}, new String[]{datos[1]}, "Tipo");
                ResultSet relTipo = conexion.rel;
                imagenesProductos[contadorImagen].setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesMenuFrappés/" + datos[0])));
                mandarVisible(1, true);
            } else {
                while (rel.next()) {
                    if (contadorImagen > 2) {
                        break;
                    }
                    conexion.consultaDato("productos", new String[]{"ProductoID"}, new String[]{rel.getString("ProductoID")}, "Nombre");
                    ResultSet relNombre = conexion.rel;
                    String datos[] = {rel.getString("Imagen"), relNombre.getString("Nombre"), String.valueOf(rel.getInt("TotalPago"))};
                    for (int i = 0; i < 2; i++) {
                        labelsPedido[contador].setText(String.format("<html>%s<html>", datos[i + 1]));
                        contador++;
                    }
                    conexion.consultaDato("productos", new String[]{"ProductoID"}, new String[]{datos[1]}, "Tipo");
                    ResultSet relTipo = conexion.rel;
                    imagenesProductos[contadorImagen].setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesMenuFrappés/" + datos[0])));
                    mandarVisible(contadorImagen + 1, true);
                    contadorImagen++;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(CarritoPagina.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        JPPrincipalSC = new javax.swing.JPanel();
        JPCabezera = new javax.swing.JPanel();
        JBTitulo = new javax.swing.JButton();
        JBCarrito = new javax.swing.JButton();
        JBUsuario = new javax.swing.JButton();
        JLNotificación = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        JPCuerpo = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        JLImgPedido1 = new javax.swing.JLabel();
        JLTituloPedido1 = new javax.swing.JLabel();
        JLPagoPedido1 = new javax.swing.JLabel();
        JSCantidadPedido1 = new javax.swing.JSpinner();
        BTEliminarPedido1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        JLProductos = new javax.swing.JLabel();
        JLTotalPago = new javax.swing.JLabel();
        JBCupon = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        JLPrecioProductos = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        JLDescuentoLabel = new javax.swing.JLabel();
        JLImgPedido2 = new javax.swing.JLabel();
        JLTituloPedido2 = new javax.swing.JLabel();
        JLPagoPedido2 = new javax.swing.JLabel();
        JSCantidadPedido2 = new javax.swing.JSpinner();
        JLImgPedido3 = new javax.swing.JLabel();
        JLTituloPedido3 = new javax.swing.JLabel();
        JLPagoPedido3 = new javax.swing.JLabel();
        JSCantidadPedido3 = new javax.swing.JSpinner();
        BTEliminarPedido2 = new javax.swing.JButton();
        BTEliminarPedido3 = new javax.swing.JButton();
        JPPiePagina = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        JBTwitter = new javax.swing.JButton();
        JBFacebook = new javax.swing.JButton();
        JBInstagram = new javax.swing.JButton();
        JBYoutube = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1280, 700));
        setName("Form"); // NOI18N
        setPreferredSize(new java.awt.Dimension(1280, 700));

        jScrollPane1.setBorder(null);
        jScrollPane1.setAutoscrolls(true);
        jScrollPane1.setDoubleBuffered(true);
        jScrollPane1.setMinimumSize(new java.awt.Dimension(1280, 700));
        jScrollPane1.setName("jScrollPane1"); // NOI18N
        jScrollPane1.setPreferredSize(new java.awt.Dimension(1280, 700));

        JPPrincipalSC.setBackground(new java.awt.Color(255, 255, 255));
        JPPrincipalSC.setForeground(new java.awt.Color(255, 255, 255));
        JPPrincipalSC.setAutoscrolls(true);
        JPPrincipalSC.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        JPPrincipalSC.setMinimumSize(new java.awt.Dimension(1260, 960));
        JPPrincipalSC.setName("JPPrincipalSC"); // NOI18N
        JPPrincipalSC.setPreferredSize(new java.awt.Dimension(1260, 960));

        JPCabezera.setBackground(new java.awt.Color(255, 255, 255));
        JPCabezera.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        JPCabezera.setMinimumSize(new java.awt.Dimension(1270, 65));
        JPCabezera.setName("JPCabezera"); // NOI18N
        JPCabezera.setPreferredSize(new java.awt.Dimension(1270, 65));

        JBTitulo.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        JBTitulo.setText("RITZKEY'S");
        JBTitulo.setBorder(null);
        JBTitulo.setBorderPainted(false);
        JBTitulo.setContentAreaFilled(false);
        JBTitulo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBTitulo.setDefaultCapable(false);
        JBTitulo.setFocusable(false);
        JBTitulo.setName("JBTitulo"); // NOI18N
        JBTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTituloActionPerformed(evt);
            }
        });

        JBCarrito.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesPgInicio/carroCompraIcon.png"))); // NOI18N
        JBCarrito.setBorder(null);
        JBCarrito.setContentAreaFilled(false);
        JBCarrito.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBCarrito.setName("JBCarrito"); // NOI18N
        JBCarrito.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBCarritoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBCarritoMouseExited(evt);
            }
        });
        JBCarrito.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBCarritoActionPerformed(evt);
            }
        });

        JBUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesPgInicio/usuarioIcon.png"))); // NOI18N
        JBUsuario.setBorder(null);
        JBUsuario.setContentAreaFilled(false);
        JBUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBUsuario.setName("JBUsuario"); // NOI18N
        JBUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                JBUsuarioMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                JBUsuarioMouseExited(evt);
            }
        });
        JBUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBUsuarioActionPerformed(evt);
            }
        });

        JLNotificación.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JLNotificación.setForeground(new java.awt.Color(255, 255, 255));
        JLNotificación.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLNotificación.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/circuloIcon.png"))); // NOI18N
        JLNotificación.setText("0");
        JLNotificación.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLNotificación.setName("JLNotificación"); // NOI18N

        jLabel1.setName("jLabel1"); // NOI18N

        javax.swing.GroupLayout JPCabezeraLayout = new javax.swing.GroupLayout(JPCabezera);
        JPCabezera.setLayout(JPCabezeraLayout);
        JPCabezeraLayout.setHorizontalGroup(
            JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(JBTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(348, 348, 348)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(349, 349, 349)
                .addComponent(JBUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(JBCarrito)
                .addGap(0, 0, 0)
                .addComponent(JLNotificación)
                .addGap(20, 20, 20))
        );
        JPCabezeraLayout.setVerticalGroup(
            JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addComponent(JBTitulo)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(JPCabezeraLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(JPCabezeraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(JLNotificación)
                        .addComponent(JBUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(JBCarrito, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        JPCuerpo.setBackground(new java.awt.Color(255, 255, 255));
        JPCuerpo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        JPCuerpo.setMinimumSize(new java.awt.Dimension(1260, 1008));
        JPCuerpo.setName("JPCuerpo"); // NOI18N
        JPCuerpo.setPreferredSize(new java.awt.Dimension(1260, 512));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Pedido");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel2.setName("jLabel2"); // NOI18N

        JLImgPedido1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLImgPedido1.setName("JLImgPedido1"); // NOI18N

        JLTituloPedido1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        JLTituloPedido1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        JLTituloPedido1.setName("JLTituloPedido1"); // NOI18N

        JLPagoPedido1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JLPagoPedido1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLPagoPedido1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLPagoPedido1.setName("JLPagoPedido1"); // NOI18N

        JSCantidadPedido1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JSCantidadPedido1.setModel(new javax.swing.SpinnerNumberModel(1, 1, 10, 1));
        JSCantidadPedido1.setName(""); // NOI18N
        JSCantidadPedido1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                JSCantidadPedido1StateChanged(evt);
            }
        });

        BTEliminarPedido1.setBackground(new java.awt.Color(255, 51, 51));
        BTEliminarPedido1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BTEliminarPedido1.setForeground(new java.awt.Color(255, 255, 255));
        BTEliminarPedido1.setText("Eliminar");
        BTEliminarPedido1.setBorder(null);
        BTEliminarPedido1.setFocusable(false);
        BTEliminarPedido1.setName("BTEliminarPedido1"); // NOI18N
        BTEliminarPedido1.setRolloverEnabled(false);
        BTEliminarPedido1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BTEliminarPedido1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BTEliminarPedido1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BTEliminarPedido1MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                BTEliminarPedido1MouseReleased(evt);
            }
        });
        BTEliminarPedido1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTEliminarPedido1ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jPanel1.setName("jPanel1"); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Total de compra");
        jLabel4.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel4.setName("jLabel4"); // NOI18N

        JLProductos.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JLProductos.setText("Productos(0)");
        JLProductos.setName("JLProductos"); // NOI18N

        JLTotalPago.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        JLTotalPago.setText("$0");
        JLTotalPago.setName("JLTotalPago"); // NOI18N

        JBCupon.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JBCupon.setForeground(new java.awt.Color(0, 0, 153));
        JBCupon.setText("Ingresar cupon");
        JBCupon.setBorderPainted(false);
        JBCupon.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        JBCupon.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        JBCupon.setName("JBCupon"); // NOI18N
        JBCupon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBCuponActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setText("Total");
        jLabel18.setName("jLabel18"); // NOI18N

        jButton2.setBackground(new java.awt.Color(249, 203, 156));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton2.setText("Proceder al pago");
        jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jButton2.setBorderPainted(false);
        jButton2.setDefaultCapable(false);
        jButton2.setName("jButton2"); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        JLPrecioProductos.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JLPrecioProductos.setText("$0");
        JLPrecioProductos.setName("JLPrecioProductos"); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        JLDescuentoLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        JLDescuentoLabel.setForeground(new java.awt.Color(0, 204, 51));
        JLDescuentoLabel.setName("JLDescuentoLabel"); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(JLProductos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(197, 197, 197))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(JBCupon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(142, 142, 142)))
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(JLPrecioProductos, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                    .addComponent(JLTotalPago, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(JLDescuentoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(16, 16, 16))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(129, 129, 129))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 282, Short.MAX_VALUE)
                .addGap(109, 109, 109))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(JLProductos)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(52, 52, 52)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(JBCupon, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(JLPrecioProductos)
                        .addGap(42, 42, 42)
                        .addComponent(JLDescuentoLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                        .addComponent(jLabel18)
                        .addGap(44, 44, 44))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(JLTotalPago)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
        );

        JLImgPedido2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLImgPedido2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLImgPedido2.setName("JLImgPedido2"); // NOI18N

        JLTituloPedido2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        JLTituloPedido2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        JLTituloPedido2.setName("JLTituloPedido2"); // NOI18N

        JLPagoPedido2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JLPagoPedido2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLPagoPedido2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLPagoPedido2.setName("JLPagoPedido2"); // NOI18N

        JSCantidadPedido2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JSCantidadPedido2.setModel(new javax.swing.SpinnerNumberModel(1, 1, 10, 1));
        JSCantidadPedido2.setName(""); // NOI18N
        JSCantidadPedido2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                JSCantidadPedido2StateChanged(evt);
            }
        });

        JLImgPedido3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLImgPedido3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLImgPedido3.setName("JLImgPedido3"); // NOI18N

        JLTituloPedido3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        JLTituloPedido3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        JLTituloPedido3.setName("JLTituloPedido3"); // NOI18N

        JLPagoPedido3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        JLPagoPedido3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        JLPagoPedido3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        JLPagoPedido3.setName("JLPagoPedido3"); // NOI18N

        JSCantidadPedido3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        JSCantidadPedido3.setModel(new javax.swing.SpinnerNumberModel(1, 1, 10, 1));
        JSCantidadPedido3.setName(""); // NOI18N
        JSCantidadPedido3.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                JSCantidadPedido3StateChanged(evt);
            }
        });

        BTEliminarPedido2.setBackground(new java.awt.Color(255, 51, 51));
        BTEliminarPedido2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BTEliminarPedido2.setForeground(new java.awt.Color(255, 255, 255));
        BTEliminarPedido2.setText("Eliminar");
        BTEliminarPedido2.setBorder(null);
        BTEliminarPedido2.setFocusable(false);
        BTEliminarPedido2.setName("BTEliminarPedido2"); // NOI18N
        BTEliminarPedido2.setRolloverEnabled(false);
        BTEliminarPedido2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BTEliminarPedido2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BTEliminarPedido2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BTEliminarPedido2MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                BTEliminarPedido2MouseReleased(evt);
            }
        });
        BTEliminarPedido2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTEliminarPedido2ActionPerformed(evt);
            }
        });

        BTEliminarPedido3.setBackground(new java.awt.Color(255, 51, 51));
        BTEliminarPedido3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BTEliminarPedido3.setForeground(new java.awt.Color(255, 255, 255));
        BTEliminarPedido3.setText("Eliminar");
        BTEliminarPedido3.setBorder(null);
        BTEliminarPedido3.setFocusable(false);
        BTEliminarPedido3.setName("BTEliminarPedido3"); // NOI18N
        BTEliminarPedido3.setRolloverEnabled(false);
        BTEliminarPedido3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BTEliminarPedido3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BTEliminarPedido3MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BTEliminarPedido3MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                BTEliminarPedido3MouseReleased(evt);
            }
        });
        BTEliminarPedido3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTEliminarPedido3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPCuerpoLayout = new javax.swing.GroupLayout(JPCuerpo);
        JPCuerpo.setLayout(JPCuerpoLayout);
        JPCuerpoLayout.setHorizontalGroup(
            JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCuerpoLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(JLImgPedido1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                    .addComponent(JLImgPedido2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(JLImgPedido3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addComponent(JLTituloPedido3, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                        .addGap(29, 29, 29))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(JLTituloPedido2, javax.swing.GroupLayout.DEFAULT_SIZE, 176, Short.MAX_VALUE)
                            .addComponent(JLTituloPedido1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JSCantidadPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JSCantidadPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JSCantidadPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JLPagoPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLPagoPedido1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(JLPagoPedido2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addComponent(BTEliminarPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(567, Short.MAX_VALUE))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BTEliminarPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(BTEliminarPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPCuerpoLayout.createSequentialGroup()
                .addGap(493, 493, 493)
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(361, 361, 361))
        );
        JPCuerpoLayout.setVerticalGroup(
            JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPCuerpoLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel2)
                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addComponent(JLTituloPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPCuerpoLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(JLImgPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPCuerpoLayout.createSequentialGroup()
                                .addComponent(JLImgPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addGap(74, 74, 74)
                                .addComponent(JLTituloPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)))
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(JLImgPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addGap(74, 74, 74)
                                .addComponent(JLTituloPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(JPCuerpoLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addComponent(BTEliminarPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(113, 113, 113)
                                .addComponent(BTEliminarPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(138, 138, 138)
                                .addComponent(BTEliminarPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(JPCuerpoLayout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(JSCantidadPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(JLPagoPedido1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(129, 129, 129)
                                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JSCantidadPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(JLPagoPedido2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(132, 132, 132)
                                .addGroup(JPCuerpoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(JSCantidadPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(JLPagoPedido3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(36, 36, 36))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JPCuerpoLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        JPPiePagina.setBackground(new java.awt.Color(255, 129, 101));
        JPPiePagina.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        JPPiePagina.setAutoscrolls(true);
        JPPiePagina.setMinimumSize(new java.awt.Dimension(1280, 200));
        JPPiePagina.setName("JPPiePagina"); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Ponte en contacto");
        jLabel5.setName("jLabel5"); // NOI18N

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("123 Centro, Amayuca");
        jLabel6.setName("jLabel6"); // NOI18N

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/CorreoIcon.png"))); // NOI18N
        jLabel7.setName("jLabel7"); // NOI18N

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("735-268-29-62 ó 735-179-80-46");
        jLabel8.setName("jLabel8"); // NOI18N

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("RitzKeys@outlook.com");
        jLabel9.setName("jLabel9"); // NOI18N

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/UbicacionIcon.png"))); // NOI18N
        jLabel10.setName("jLabel10"); // NOI18N

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/LlamadaIcon.png"))); // NOI18N
        jLabel11.setName("jLabel11"); // NOI18N

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setText("Horario");
        jLabel12.setName("jLabel12"); // NOI18N

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel13.setText("<html>Puedes seguirnos en nuestras redes sociales</html>");
        jLabel13.setName("jLabel13"); // NOI18N

        jLabel15.setBackground(new java.awt.Color(255, 255, 255));
        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel15.setText("<html>Lunes - Sábado<br> 12:00 PM - 7:00 PM</html>");
        jLabel15.setName("jLabel15"); // NOI18N

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Síguenos");
        jLabel14.setName("jLabel14"); // NOI18N

        JBTwitter.setBackground(new java.awt.Color(255, 129, 101));
        JBTwitter.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon.png"))); // NOI18N
        JBTwitter.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));
        JBTwitter.setContentAreaFilled(false);
        JBTwitter.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBTwitter.setFocusPainted(false);
        JBTwitter.setName("JBTwitter"); // NOI18N
        JBTwitter.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon.png"))); // NOI18N
        JBTwitter.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/twitterIcon2.png"))); // NOI18N
        JBTwitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTwitterActionPerformed(evt);
            }
        });

        JBFacebook.setBackground(new java.awt.Color(255, 129, 101));
        JBFacebook.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon.png"))); // NOI18N
        JBFacebook.setBorder(null);
        JBFacebook.setContentAreaFilled(false);
        JBFacebook.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBFacebook.setFocusPainted(false);
        JBFacebook.setName("JBFacebook"); // NOI18N
        JBFacebook.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon.png"))); // NOI18N
        JBFacebook.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/facebookIcon2.png"))); // NOI18N
        JBFacebook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBFacebookActionPerformed(evt);
            }
        });

        JBInstagram.setBackground(new java.awt.Color(255, 129, 101));
        JBInstagram.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon.png"))); // NOI18N
        JBInstagram.setBorder(null);
        JBInstagram.setContentAreaFilled(false);
        JBInstagram.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBInstagram.setFocusPainted(false);
        JBInstagram.setName("JBInstagram"); // NOI18N
        JBInstagram.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon.png"))); // NOI18N
        JBInstagram.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/InstagramIcon2.png"))); // NOI18N
        JBInstagram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBInstagramActionPerformed(evt);
            }
        });

        JBYoutube.setBackground(new java.awt.Color(255, 129, 101));
        JBYoutube.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon.png"))); // NOI18N
        JBYoutube.setBorder(null);
        JBYoutube.setContentAreaFilled(false);
        JBYoutube.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        JBYoutube.setFocusPainted(false);
        JBYoutube.setName("JBYoutube"); // NOI18N
        JBYoutube.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon.png"))); // NOI18N
        JBYoutube.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/IngenieriaSF/ImagenesInicioSesion/youtubeIcon2.png"))); // NOI18N
        JBYoutube.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBYoutubeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout JPPiePaginaLayout = new javax.swing.GroupLayout(JPPiePagina);
        JPPiePagina.setLayout(JPPiePaginaLayout);
        JPPiePaginaLayout.setHorizontalGroup(
            JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel7)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGap(59, 59, 59)
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel14)
                        .addGap(49, 49, 49)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addGap(92, 92, 92)
                                .addComponent(jLabel12))
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addGap(63, 63, 63)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(JPPiePaginaLayout.createSequentialGroup()
                            .addComponent(JBTwitter)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JBFacebook)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JBInstagram)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JBYoutube))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JPPiePaginaLayout.setVerticalGroup(
            JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel10)
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel14))
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel11)
                            .addGroup(JPPiePaginaLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(JPPiePaginaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(JBTwitter, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(JBFacebook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(JBYoutube, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                    .addGroup(JPPiePaginaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(JBInstagram))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, JPPiePaginaLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel12)))
                .addContainerGap())
        );

        javax.swing.GroupLayout JPPrincipalSCLayout = new javax.swing.GroupLayout(JPPrincipalSC);
        JPPrincipalSC.setLayout(JPPrincipalSCLayout);
        JPPrincipalSCLayout.setHorizontalGroup(
            JPPrincipalSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JPCuerpo, javax.swing.GroupLayout.DEFAULT_SIZE, 1270, Short.MAX_VALUE)
            .addGroup(JPPrincipalSCLayout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(JPPiePagina, javax.swing.GroupLayout.PREFERRED_SIZE, 1268, Short.MAX_VALUE)
                .addGap(1, 1, 1))
            .addComponent(JPCabezera, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        JPPrincipalSCLayout.setVerticalGroup(
            JPPrincipalSCLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPPrincipalSCLayout.createSequentialGroup()
                .addComponent(JPCabezera, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(JPCuerpo, javax.swing.GroupLayout.PREFERRED_SIZE, 706, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(JPPiePagina, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1))
        );

        jScrollPane1.setViewportView(JPPrincipalSC);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void JBTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTituloActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        PaginaInicio paginaInicio = new PaginaInicio(JPPrincipal);
    }//GEN-LAST:event_JBTituloActionPerformed

    private void JBCarritoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCarritoMouseEntered
        JBCarrito.setBorder(new LineBorder(Color.BLACK));
    }//GEN-LAST:event_JBCarritoMouseEntered

    private void JBCarritoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBCarritoMouseExited
        JBCarrito.setBorder(null);
    }//GEN-LAST:event_JBCarritoMouseExited

    private void JBCarritoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBCarritoActionPerformed

    }//GEN-LAST:event_JBCarritoActionPerformed

    private void JBUsuarioMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBUsuarioMouseEntered
        JBUsuario.setBorder(new LineBorder(Color.BLACK));
    }//GEN-LAST:event_JBUsuarioMouseEntered

    private void JBUsuarioMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_JBUsuarioMouseExited
        JBUsuario.setBorder(null);
    }//GEN-LAST:event_JBUsuarioMouseExited

    private void JBUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBUsuarioActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new UsuarioPagina(JPPrincipal);
    }//GEN-LAST:event_JBUsuarioActionPerformed

    private void JBTwitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTwitterActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://twitter.com/?lang=es"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBTwitterActionPerformed

    private void JBFacebookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBFacebookActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.facebook.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBFacebookActionPerformed

    private void JBInstagramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBInstagramActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.instagram.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBInstagramActionPerformed

    private void JBYoutubeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBYoutubeActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://www.youtube.com/"));
        } catch (Exception ex) {
            Logger.getLogger(InicioSesión.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_JBYoutubeActionPerformed

    private void BTEliminarPedido1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido1MouseEntered
        BTEliminarPedido1.setBackground(new Color(190, 69, 69));
    }//GEN-LAST:event_BTEliminarPedido1MouseEntered

    private void BTEliminarPedido1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido1MouseExited
        BTEliminarPedido1.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_BTEliminarPedido1MouseExited

    private void BTEliminarPedido1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido1MousePressed
        BTEliminarPedido1.setBackground(new Color(236, 136, 136));
    }//GEN-LAST:event_BTEliminarPedido1MousePressed

    private void BTEliminarPedido1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido1MouseReleased
        BTEliminarPedido1.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_BTEliminarPedido1MouseReleased

    private void BTEliminarPedido1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTEliminarPedido1ActionPerformed
        limpiarLabels();
        llenarLabels();
        JPPrincipalSC.revalidate();
        JPPrincipalSC.repaint();
    }//GEN-LAST:event_BTEliminarPedido1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JPPrincipal.removeAll();
        JPPrincipal.revalidate();
        JPPrincipal.repaint();
        new FinalizarPedido(JPPrincipal);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void JSCantidadPedido1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_JSCantidadPedido1StateChanged

    }//GEN-LAST:event_JSCantidadPedido1StateChanged

    private void JSCantidadPedido2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_JSCantidadPedido2StateChanged

    }//GEN-LAST:event_JSCantidadPedido2StateChanged

    private void JSCantidadPedido3StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_JSCantidadPedido3StateChanged

    }//GEN-LAST:event_JSCantidadPedido3StateChanged

    private void BTEliminarPedido3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido3MouseEntered
        BTEliminarPedido3.setBackground(new Color(190, 69, 69));
    }//GEN-LAST:event_BTEliminarPedido3MouseEntered

    private void BTEliminarPedido3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido3MouseExited
        BTEliminarPedido3.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_BTEliminarPedido3MouseExited

    private void BTEliminarPedido3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido3MousePressed
        BTEliminarPedido3.setBackground(new Color(236, 136, 136));
    }//GEN-LAST:event_BTEliminarPedido3MousePressed

    private void BTEliminarPedido3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido3MouseReleased
        BTEliminarPedido3.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_BTEliminarPedido3MouseReleased

    private void BTEliminarPedido3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTEliminarPedido3ActionPerformed

        limpiarLabels();
        llenarLabels();
        JPPrincipalSC.revalidate();
        JPPrincipalSC.repaint();
    }//GEN-LAST:event_BTEliminarPedido3ActionPerformed

    private void BTEliminarPedido2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTEliminarPedido2ActionPerformed

        limpiarLabels();
        llenarLabels();
        JPPrincipalSC.revalidate();
        JPPrincipalSC.repaint();
    }//GEN-LAST:event_BTEliminarPedido2ActionPerformed

    private void BTEliminarPedido2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido2MouseReleased
        BTEliminarPedido2.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_BTEliminarPedido2MouseReleased

    private void BTEliminarPedido2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido2MousePressed
        BTEliminarPedido2.setBackground(new Color(236, 136, 136));
    }//GEN-LAST:event_BTEliminarPedido2MousePressed

    private void BTEliminarPedido2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido2MouseExited
        BTEliminarPedido2.setBackground(new Color(255, 51, 51));
    }//GEN-LAST:event_BTEliminarPedido2MouseExited

    private void BTEliminarPedido2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BTEliminarPedido2MouseEntered
        BTEliminarPedido2.setBackground(new Color(190, 69, 69));
    }//GEN-LAST:event_BTEliminarPedido2MouseEntered

    private void JBCuponActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBCuponActionPerformed
        IngresaCupon Cupon = new IngresaCupon();
        Cupon.mandarCarrito(this);
        Cupon.setVisible(true);
    }//GEN-LAST:event_JBCuponActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton BTEliminarPedido1;
    public javax.swing.JButton BTEliminarPedido2;
    public javax.swing.JButton BTEliminarPedido3;
    public javax.swing.JButton JBCarrito;
    public javax.swing.JButton JBCupon;
    public javax.swing.JButton JBFacebook;
    public javax.swing.JButton JBInstagram;
    public javax.swing.JButton JBTitulo;
    public javax.swing.JButton JBTwitter;
    public javax.swing.JButton JBUsuario;
    public javax.swing.JButton JBYoutube;
    public javax.swing.JLabel JLDescuentoLabel;
    public javax.swing.JLabel JLImgPedido1;
    public javax.swing.JLabel JLImgPedido2;
    public javax.swing.JLabel JLImgPedido3;
    public javax.swing.JLabel JLNotificación;
    public javax.swing.JLabel JLPagoPedido1;
    public javax.swing.JLabel JLPagoPedido2;
    public javax.swing.JLabel JLPagoPedido3;
    public javax.swing.JLabel JLPrecioProductos;
    public javax.swing.JLabel JLProductos;
    public javax.swing.JLabel JLTituloPedido1;
    public javax.swing.JLabel JLTituloPedido2;
    public javax.swing.JLabel JLTituloPedido3;
    public javax.swing.JLabel JLTotalPago;
    public javax.swing.JPanel JPCabezera;
    public javax.swing.JPanel JPCuerpo;
    public javax.swing.JPanel JPPiePagina;
    public javax.swing.JPanel JPPrincipalSC;
    public javax.swing.JSpinner JSCantidadPedido1;
    public javax.swing.JSpinner JSCantidadPedido2;
    public javax.swing.JSpinner JSCantidadPedido3;
    public javax.swing.JButton jButton2;
    public javax.swing.JLabel jLabel1;
    public javax.swing.JLabel jLabel10;
    public javax.swing.JLabel jLabel11;
    public javax.swing.JLabel jLabel12;
    public javax.swing.JLabel jLabel13;
    public javax.swing.JLabel jLabel14;
    public javax.swing.JLabel jLabel15;
    public javax.swing.JLabel jLabel18;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel4;
    public javax.swing.JLabel jLabel5;
    public javax.swing.JLabel jLabel6;
    public javax.swing.JLabel jLabel7;
    public javax.swing.JLabel jLabel8;
    public javax.swing.JLabel jLabel9;
    public javax.swing.JPanel jPanel1;
    public javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

}
